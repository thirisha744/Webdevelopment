let fetchedData = fetch("https://fakestoreapi.com/products")
let ol=document.querySelector("ol")
console.log(fetchedData);  //promise
fetchedData.then((data)=>{
    console.log(data);  //response

    let jsondata=data.json()
    console.log(jsondata);  //promise

    jsondata.then((data)=>{
        console.log(data);   //original data
        data.map((ele)=>{
            console.log(ele.title);
            let li=document.createElement("li")
            li.innerText=ele.title
            ol.append(li)
        })

    })
    .catch((err)=>{
        console.log(err);    
        
    })    
    
})
.catch((err)=>{
    console.log(err);
    
})
