let arr=[10,"html",true,[3,4]]
console.log(arr);

//! how to know the length of the array
console.log(arr.length);

//! array methods
//! 1.push()
//it is used to add element at the end of the array. return the size of the new array
let arr1=[10,20,30]
console.log(arr1);
arr1.push(40)
console.log(arr1);
//! 2.pop()
//it is used to remove the last element from the array.return the removed element
let arr2=[10,20,30]
arr2.pop()
console.log(arr2);
//! 3.unshift()
//this method used to add the element at the starting of the array
let arr3=[20,30]
arr3.unshift(10)
console.log(arr3);
//! 4.shift()
//this method used to remove the element at the starting of the array
let arr4=[5,10,20,30]
arr4.shift()
console.log(arr4);
//! 5.includes()
//it is used to know the given element is present or not . if the element is present in the array it will return true else it will return false
let arr5=[10,20,30,40,30]
console.log(arr5.includes(20));
console.log(arr5.includes(100));
//! 6.indexof()
//it gives the index of the element 
console.log(arr5.indexOf(30));
//! 7.lastindexof()
//it gives the end index of the particular element
console.log(arr5.lastIndexOf(30));
//! 8.concat()
//combine two or more than two array and return a new array
let sub1=["html","css"]
let sub2=["java","python"]
console.log(sub1.concat(sub2));
//! 9.reverse()
//reverse the element in the array
let arr6=[10,20,30,40,50]
console.log(arr6.reverse());
//!10. join()
//it is used to convert any array into string. 
let msg=['h','e','l','l','o']
console.log(msg.join(""));

// let str="hello"
// str.split(" ");
// str.reverse();
// console.log(str.join(""));

//!higherorder array method ********
//! 1.map()
//map() method is higherorder array method it is used to traverse the array and we can do any operation with all the elements
//map() method will take one callback function and here it can take 3 parameters(element,index,array)
//this method will return one new array
let num=[10,20,30,40,50]
let m=num.map((element,index,array)=>{
    return element+200;
})
console.log(m)

let sub=["html","css","js","java","python"]
let m1=sub.map((element)=>{
    return element.toUpperCase()
})
console.log(m1);

//! 2.filter()
//it is one higherorder array method it is used to traverse the array and check the condition and it will return one new array.
//filter() method will take one callback function and here it can take 3 parameters(element,index,array)
let f=num.filter((e)=>{
    return e>30
})
console.log(f);

//! 3.reduce()
//it is one higherorder array method it is used to reduce the array elements into single value by adding or multiplying.
//it will take four parameter in the callback function(accumulator,element,index,array) 
let sum=num.reduce((acc,element)=>{
    return acc+element
})
console.log(sum);

//we can change the accumulator value
let sum1=num.reduce((acc,element)=>{
    return acc+element
},100)
console.log(sum1);

let mul=num.reduce((acc,element)=>{
    return acc*element
},1)
console.log(mul);

//! 4.sort()
//sort() is higherorder array method. it is used to sort the array in ascending or descending order
//it takes two parameters in the callback function. if we are giving first parameter minus second parameter(a-b) means ascending order and (b-a) means descending.
let arr7=[5,2,3,1,9,8]
let asc=arr7.sort((a,b)=>{
    return a-b
})
console.log(asc);

let des=arr7.sort((a,b)=>{
    return b-a
})
console.log(des);

//! 5.foreach()
//foreach() method is higherorder array method it is used to traverse the array and we can do any operation with all the elements
//foreach() method will take one callback function and here it can take 3 parameters(element,index,array)
//difference between for each and map is map can return but foreach cannot return 
let arr8=[2,6,8,10]
arr8.forEach((ele)=>{
    console.log(ele+100);
})


let ar=[100,200,300,400,500]
ar.splice(2,2,600);
console.log(ar);


let arrr=[10,20,30,40,50]
arrr.splice(2,0,25);
console.log(arrr);


























