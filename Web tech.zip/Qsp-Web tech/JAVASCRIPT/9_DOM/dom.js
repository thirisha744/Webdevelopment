//! 1.how to target elements
//? by id
let logo=document.getElementById("logo")
console.log(logo);

//? by class
let cards=document.getElementsByClassName("card")
console.log(cards)

let secondCard = cards[1]
console.log(secondCard);

let btn=document.getElementsByClassName("btn")
console.log(btn);

//? by tagname

let list=document.getElementsByTagName("li")
console.log(list[2]);

//? query selector
let logo2=document.querySelector("#logo")
console.log(logo2);

let card1=document.querySelector(".card")
console.log(card1);

let li=document.querySelector("li")
console.log(li);

//? query selectorall
let li1=document.querySelectorAll("li")
console.log(li1);

let card2=document.querySelectorAll(".card")
console.log(card2);
console.log(card2[2]);

//! how to get or set content inside element
let cardss=document.getElementsByClassName("card")
console.log(cardss[1].innerText);
console.log(cardss[1].innerHTML);

console.log(cardss[2]);

cardss[2].innerHTML="<h2>I am from js file</h2> <p>i am paragraph</p>"
//cardss[2].innerText="<h1> hii</h1>"

//! how to apply css
let items=document.getElementsByTagName("li")
console.log(items)
let about=items[1]
console.log(about);
about.style.color="red"
about.style.textDecoration="underline"

//! how to add/remove class
//! how to apply multiple css
 let firstCard=document.querySelector(".card")
 console.log(firstCard.classList);

 firstCard.classList.add("dark")
 console.log(firstCard.classList);
 
 firstCard.classList.remove("dark")

//! how to create any element
let div=document.createElement("div")
div.classList.add("circle")

// cardss[2].prepend(div)
// cardss[2].append(div)
// cardss[2].before(div)
cardss[2].after(div)


let footer=document.createElement("div")
footer.classList.add("footer")
footer.innerHTML=`<p>dom task 2025</p>`
let main=document.querySelector("main")

console.log(main);
main.after(footer)
