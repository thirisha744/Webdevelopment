// how to create function
//1. named function
function display(){
    console.log("i am display function")
}
display()
// function with parameter
function add(a, b)
{
    console.log(a+b);
    
}
add(5,5)
add(6,10)

//function with return keyword
function sub(a, b){
    return a-b;
}
let res=sub(90,40)
console.log(res);

// function with expression //anonynms function
let msg=function(){
    console.log("hello everyone...");  
}
msg()

// arrow function
let multiply = (a, b)=>{
    console.log(a*b);
}
multiply(30,3)

//nested fuction
let outer=()=>{
    console.log("i am outer function");
    let inner=()=>{
        console.log("i am inside function");
    }
    inner()
}
outer()

// ! Lexical Scoping 
//in nested function inner function can access all the properties of outer function but outer function can't access the properties of inner function, this is called lexical scoping
let parent=()=>{
    let a=10;
    let child=()=>{
        let b=20;
        console.log(b);
        console.log(a);
    }
    child()
    // console.log(b);
}
parent()

//! higher order function and callback function *****
//any function that takes another function as parameter
//the function we are sending as a parameter to the higher order function is called as callback function
let hof=(a)=>{
    a()
}
hof(()=>{
    console.log("higher order and callback function");
    
});

//! IIFE(Immediate Invoke Function Expression)
(function(){
    console.log("i am iife function");
    
})()

