console.log("timing Function in js");
console.log("start");

let display=()=>{
    console.log("I am display function");    
}
//! setTimeOut()
// setTimeout(display,4000)
// console.log("end");

// setTimeout(() => {
//     console.log("I am settimeout");
    
// }, 5000);

// let wish=()=>{
//     console.log("happy day 😊😊😊");
// }
// setTimeout(wish,6000)

// let bye=()=>{
//     console.log("byeee👋👋👋");
// }
// setInterval(bye,7000)

let st=setTimeout(() => {
    console.log("i am settimeout");
}, 3000);
clearTimeout(st)

let si=setInterval(() => {
    console.log("i am set interval");
}, 4000);
clearInterval(si)



