console.log("I am external javascript");

// var keyword redeclaration is possible but let redeclaration is not possible

// how to declare variable
// let keyword
let sname="Thirisha"
console.log(sname);
// var keyword
var age
age=21
console.log(age);
var age=12;
console.log(age);
// redeclaration is possible in var keyword
// const keyword
const aadharNo=123456789812
console.log(aadharNo);
// aadharNo=987456321012
//const PI
// PI=3.14
// console.log(aadharNo) const redeclaration and re-initialization is not possible

// datatypes in javascript
// 1)Primitive 2)non Primitive datatype
/* Primitive datatype 
1.number 2.boolean 3.string 4.undefined 5.null 6.bigint*/
// number
let ph=1234567890
console.log(ph);
console.log(typeof ph);
let salary=20000.50
console.log(salary);
console.log(typeof salary);
// how to know the datatype  by using typeof operator
// boolean
let isMarried=true
console.log(isMarried);
console.log(typeof isMarried);
let hasKid=false
console.log(typeof hasKid);
// string
let city ="chennai"
let state='tamilnadu'
let country=`India`
console.log(city)
console.log(state);
console.log(country);

console.log(typeof city);
console.log(typeof state);
console.log(typeof country);
// undefined
// any variable is declared but not initialized is called undefined
let wifeName
console.log(wifeName);
console.log(typeof wifeName);

// null
let hasGf=null
console.log(hasGf);
console.log(typeof hasGf); //object

// bigint
let largeNum=2n
console.log(largeNum);
console.log(typeof largeNum);

//2. Non - primitive datatypes
//array,function,object

//array
let arr=[20,'html',true,undefined]
console.log(arr);
//function
function add(){
    console.log("i am add function");
}
add()

//object
let emp={
    ename:"miller",
    empid:1001
}
console.log(emp);
console.log(emp.ename)
console.log(emp.empid);

//! variable hosting
//variable hosting means we trying to access the variable before its declaration and also the variable should be var then the declaration part goes to top this is known as hosting and output will be undefined
//this is not possible in let keyword. 
console.log(sname); //undefined
var Nname="santanu"
console.log(Nname);

// console.log(phno);  //error
let phno=123456
console.log(phno);

//var having global scope but let and const is local scope
{
    var a=10
    let b=20
    const c=30
}
console.log(a);//10
// console.log(b);//error
// console.log(c);//error













