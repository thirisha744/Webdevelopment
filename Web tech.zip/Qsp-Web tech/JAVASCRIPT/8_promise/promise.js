//PROMISE IS ONE JAVASCRIPT OBJECT USED TO HANDLE ASYNCHRONIZED OPERATION 
//WE CAN CREATE PROMISE BY USING NEW KEYWORD.
//IT WILL TAKE ONE CALL BACK FUNCTION THERE IT WILL TAKE TWO PARAMETER (RESOLVE, REJECT)
//FOR HANDLING THE RESOLVE WE NEED .THEN BLOCK AND FOR HANDLING THE REJECT WE NEED .CATCH BLOCK.
//PROMISE HAVING THREE STATES PENDING,FULFILLED AND REJECT
let p=new Promise((resolve,reject)=>{
    let studied = true
    if(studied){
        resolve("i will give mock")
    }
    else{
        reject("i will not give mock")
    }
})
console.log(p);

p
.then((data)=>{
    console.log(data);
})
.catch((err)=>{
    console.log(err);
    
})
.finally(console.log("i am finally block")) //execute every time 


let p1=new Promise((resolve, reject)=>{
    let student=true;
    if(student){
        console.log("yes i am a student");
    }
    else{
        console.log("no i am not a student");
    }
})

p1
.then((data)=>{
    console.log(data);
})
.catch((err)=>{
    console.log(err);
})
.finally(
    console.log("any way i am a human")
    
)


let p2=new Promise((resolve,reject)=>{
    resolve("hii")
})
console.log(p2);

p2
.then((data)=>{
    console.log(data);
    
})


let p3=new Promise((resolve,reject)=>{
    reject("hii")

})
console.log(p3);

p3
.then((data)=>{
    console.log(data);
})
.catch((err)=>{
    console.log(err);
    
})