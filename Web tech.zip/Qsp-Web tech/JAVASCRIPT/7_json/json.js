//JSON(javascript object Notation) is a light weight data-interchange format
//that is easy for humans to read and write, and easy for machines to parse and generate
//! Advantages of JSON:
//? Human-Readable:
//json's structure is easy for developers to understand and write
//? LightWeight:
//JSON is a minimal format that reduces the size of the data being transmitted.
//? Language-Independent:
//JSON can be used with many programming language,
//including javascript,python,Ruby,java,etc.

let person={
    personName:"sha",
    age:21,
    city:"chennai",
    isPlayer:true
};
console.log(person);
//json-> javascript object notation
//! JSON.stringify()
//this method is used to convert any javascript object into json.
let jsonData=JSON.stringify(person)
console.log(jsonData);
console.log(typeof jsonData);

//! JSON.parse()
//this method is used to convert any json into javascript object.
let ob1=JSON.parse(jsonData)
console.log(ob1);

let employee=[
    {
        eid:101,
        ename:"miller",
        sal:10000
    },
    {
        eid:201,
        ename:"scott",
        sal:20000
    },
    {
        eid:301,
        ename:"adams",
        sal:30000
    }
]
console.log(employee);

employee.map((ele)=>{
    console.log(ele);
    
})
employee.map((ele)=>{
    console.log(ele.ename)
})

let student={
    stuName:"xxx",
    age:10,
    isStudent: true,
    skills:["html","css","js"]
}

//! destructure
// here we make all the object as seperate and we can access  them without dot operator. 
//for example console.log(student.age) as console.log(age)
let {stuName,age,isStudent,skills}=student
console.log(stuName);
console.log(skills);

//! rest parameter
//rest of things stored in same variable 
let display=(a,b,...c)=>{
    console.log(a);
    console.log(b);
    console.log(c);   
}

display(10,20,30,40,50,60)

//! spread operator
//making element individual 
let arr1=[10,20,30]
let arr2=[40,50,60]
console.log(arr1,arr2);
let arr3=[...arr1,...arr2]
console.log(arr3);

let arr4=[1,2,3,4,5,6,7,8,9,10]
let[a,b,...c]=arr4  //destructure //rest parameter
console.log(a);
console.log(b);
console.log(c);



descending  