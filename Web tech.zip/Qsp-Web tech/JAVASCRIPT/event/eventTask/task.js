let outer=document.querySelector(".outer")
console.log(outer);

let ChangeRed=()=>{
    outer.style.backgroundColor="red"
}
let ChangeBlue=()=>{
    outer.style.backgroundColor="blue"
}
let ChangeGreen=()=>{
    outer.style.backgroundColor="green"
}
let ChangeBlack=()=>{
    outer.style.backgroundColor="black"
}
let ChangeViolet=()=>{
    outer.style.backgroundColor="violet"
}