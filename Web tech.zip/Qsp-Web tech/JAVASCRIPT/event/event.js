console.log("event in js");

let display=()=>{
    console.log("i am display function");
}
let changecolor=()=>{
    let select=document.querySelector("button")
    select.style.backgroundColor="blue"
}

let printMsg=()=>{
    alert("WELCOME")
}

let copy=()=>{
    let card=document.querySelector(".card1")
    let text=card.innerHTML;
    let card2=document.querySelector(".card2")
    card2.innerHTML=text
    card.innerHTML=""
    
}

let changeBackground=()=>{
    let box=document.querySelector(".box")
    box.style.backgroundColor="blue"
    console.log("hello");
}

let changeBackground2=()=>{
    let box=document.querySelector(".box")
    box.style.backgroundColor="black"
    console.log("hii");
    

}